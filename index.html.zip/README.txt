HEVILL ALPHA WEB V1
===================

Open index.html in a modern browser to preview the first HEVILL web interface.

This is a front-end prototype. The Neira AI and chat screens currently use
demo responses. The real backend services are in the earlier HEVILL packages.

To publish it publicly, upload index.html to a static web host.

Do not place private API keys in index.html.
